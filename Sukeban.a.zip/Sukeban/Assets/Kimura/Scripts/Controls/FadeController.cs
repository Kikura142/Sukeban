﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FadeController : MonoBehaviour
{
    float fadeSpeed = 0.02f;
    float red, green, blue, alfa;

    public bool isFadeOut = false;

    Image fadeImage;

    public void StartFadeOut()
    {
        if (isFadeOut)
        {
            Update();
        }

    }

    // Start is called before the first frame update
    void Start()
    {
        fadeImage = GetComponent<Image>();
        red = fadeImage.color.r;
        green = fadeImage.color.g;
        blue = fadeImage.color.b;
        alfa = fadeImage.color.a;
    }

    // Update is called once per frame
    void Update()
    {
        fadeImage.enabled = true;
        alfa += fadeSpeed;
        SetAlpha();
        if (alfa >= 1)
        {
            isFadeOut = false;
        }
    }


    void SetAlpha()
    {
        fadeImage.color = new Color(red, green, blue, alfa);
    }

}
