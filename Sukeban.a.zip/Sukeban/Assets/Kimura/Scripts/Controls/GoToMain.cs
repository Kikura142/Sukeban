﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GoToMain : MonoBehaviour
{
    public FadeController fade;

    private bool firstPush = false;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        /**/
        if (fade.isFadeOut)
        {
            SceneManager.LoadScene("Main");
        }
    }

    public void PressStart()
    {
        if (!firstPush)
        {
            /**/
            if (fade != null)
            {
                fade.StartFadeOut();
                firstPush = true;
            }
            SceneManager.LoadScene("Main");
            firstPush = true;
        }

    }


}
